# NOVA v4.0 Complete Build Checklist

## What's included
- `NOVA_v4.0.html`: single-file mobile-first interface, avatar, chat, local commands, memory, voice, translation, settings, custom wardrobe.
- `worker.js`: Cloudflare Worker AI backend with `/health`, `/chat`, and `/translate` routes.
- `wrangler.toml`: Workers AI binding configuration.
- `android-bridge/`: native bridge, wake-word foreground service, floating overlay service, and manifest.
- `README_HINGLISH.md`: deployment instructions.

## Bring-up order
1. Deploy the Worker and bind Workers AI as `AI`.
2. Test `GET /health` and confirm `ok: true`.
3. Open the HTML over HTTPS or localhost; do not use `file://` for mic features.
4. In Settings, enter the Worker URL and run Test Connection.
5. Test chat, language, speech input/output, `/help`, `/remember`, `/memory`, `/forget`, and `/clear`.
6. Android native features require a WebView wrapper, native permissions, and testing on-device; a plain browser cannot provide always-on wake-word or overlay behavior.

## Security notes
- Do not place AI keys in the HTML.
- The Worker needs its Workers AI binding named `AI`.
- The Worker currently has broad CORS (`*`). For a public deployment, consider restricting allowed origins to your hosted frontend after its URL is known.
- Keep phone permissions optional and only grant what you use.

## Validation performed on this package
- Frontend inline JavaScript syntax checked with Node.
- Worker JavaScript syntax checked with Node.
- Android Kotlin source is included but requires Android Studio/SDK for compilation and device testing.
