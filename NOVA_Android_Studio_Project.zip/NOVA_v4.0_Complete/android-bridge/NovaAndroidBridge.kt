package com.nova.companion

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.widget.Toast

/**
 * Exposes `window.NovaAndroidBridge` inside NOVA_v4.0.html WebView.
 * Safely launches installed Android apps, starts foreground wake-word service,
 * or requests floating overlay permission.
 */
class NovaAndroidBridge(private val context: Context) {

    private val packageMap = mapOf(
        "youtube" to "com.google.android.youtube",
        "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android",
        "spotify" to "com.spotify.music",
        "google maps" to "com.google.android.apps.maps",
        "gmail" to "com.google.android.gm",
        "telegram" to "org.telegram.messenger",
        "amazon" to "in.amazon.mShop.android.shopping",
        "flipkart" to "com.flipkart.android",
        "play store" to "com.android.vending"
    )

    @JavascriptInterface
    fun openApp(appKey: String): Boolean {
        val pkg = packageMap[appKey.lowercase().trim()] ?: return false
        val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            true
        } else {
            false
        }
    }

    @JavascriptInterface
    fun startWakeWordService() {
        val intent = Intent(context, NovaWakeWordService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    @JavascriptInterface
    fun stopWakeWordService() {
        context.stopService(Intent(context, NovaWakeWordService::class.java))
    }

    @JavascriptInterface
    fun toggleFloatingBubble() {
        if (!Settings.canDrawOverlays(context)) {
            Toast.makeText(context, "Please allow 'Display over other apps' for NOVA", Toast.LENGTH_LONG).show()
            val permIntent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(permIntent)
            return
        }
        val intent = Intent(context, NovaFloatingOverlayService::class.java)
        context.startService(intent)
    }
}
