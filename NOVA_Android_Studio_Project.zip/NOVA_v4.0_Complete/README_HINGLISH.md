# NOVA v4.0 — Complete Personal AI Companion (Hinglish & English Setup Guide)

Is package mein tumhara upgraded **NOVA v4.0** project hai — jisme tumhara selected pink-haired anime avatar, pastel-purple UI, real AI backend, Hindi/Hinglish/English voice & translation, memory commands, aur Android native bridge files shamil hain.

## Package Contents
- `NOVA_v4.0.html` — Complete mobile-first NOVA frontend (selected pink-haired anime avatar, idle/listening/thinking/talking states, voice mode, EN→HI translation, retry support, aur saare existing commands preserved).
- `worker.js` — Secure Cloudflare Worker AI backend (`/health`, `/chat`, `/translate`). API credentials Cloudflare par safe rehte hain; frontend HTML mein koi API key nahi hai.
- `wrangler.toml` — Cloudflare Workers AI binding (`AI`) configuration.
- `android-bridge/` — Native Android Kotlin files (`AndroidManifest.xml`, `NovaAndroidBridge.kt`, `NovaWakeWordService.kt`, `NovaFloatingOverlayService.kt`) for app launching, floating bubble, aur screen-off `"Hey NOVA"` foreground microphone service.

---

## Step 1: Free AI Backend Setup (Cloudflare Workers AI)

1. Phone ya PC browser mein `https://dash.cloudflare.com/` kholo aur free account banao/login karo.
2. Left menu mein **Workers & Pages** → **Create** → **Create Worker** select karo.
3. Worker ka naam `nova-ai-backend` rakho aur **Deploy** dabao.
4. Ab **Edit code** kholo, default code hata kar is folder ki `worker.js` ka poora code paste karo, aur **Save and Deploy** dabao.
5. Worker ke **Settings** → **Bindings** (ya **AI**) section mein jao → **Add Binding** → **Workers AI** select karo → Variable name bilkul `AI` rakho → Save karo.
6. Apna Worker URL copy karo (e.g., `https://nova-ai-backend.tumhara-naam.workers.dev`).

### Free-Tier & Cost Transparency
- Cloudflare Workers AI mein ek **free daily Neurons allocation** milta hai (default model: `@cf/meta/llama-3.1-8b-instruct-fp8-fast`).
- Agar daily free limit khatam ho jaye toh us din requests fail ho sakti hain — jab tak tum khud paid plan enable na karo, **koi charge nahi lagega**.

---

## Step 2: NOVA Frontend Chalana (Phone par)

1. `NOVA_v4.0.html` ko phone mein **Acode**, **Spck Editor**, ya kisi HTTPS host (GitHub Pages / Cloudflare Pages) par kholo.
   *(Note: `file://` se kholne par Android Chrome microphone aur YouTube embed block karta hai — isliye local server ya HTTPS use karein).*
2. Top-right **⚙️ Settings** kholo:
   - **Secure AI Backend** mein apna Worker URL paste karke **Save URL** aur **Test Connection** dabao.
   - **Auto-speak AI replies (Voice Mode)** aur apni pasand ki soft feminine voice select karo.
3. Chat mein `"Hi NOVA, aaj mera din kaisa rahega?"` ya Hindi/Hinglish mein koi bhi baat likho ya mic (🎙️) se bolo.

---

## Step 3: Native Android Integration (Screen-Off "Hey NOVA" & Floating Bubble)

- **Important Reality Check:** Ek normal web browser (`NOVA_v4.0.html`) Android security ki wajah se screen off hone par 24/7 microphone nahi sun sakta.
- Screen-off `"Hey NOVA"`, floating assistant bubble, aur installed Android apps directly kholne ke liye Android Studio mein ek WebView wrapper app banakar `android-bridge/` ke 4 files add karein:
  1. `NOVA_v4.0.html` ko Android project ke `app/src/main/assets/` mein rakhein.
  2. WebView mein `webView.addJavascriptInterface(NovaAndroidBridge(this), "NovaAndroidBridge")` register karein.
  3. Permissions grant karein: **Microphone (`RECORD_AUDIO`)**, **Display over other apps (`SYSTEM_ALERT_WINDOW`)**, aur **Battery Optimization Unrestricted** (taaki OS background service band na kare).

---

## Commands Reference
- `/help` — Saare commands ki list
- `/remember [note]` — Preference ya note save karein (e.g., `/remember Mujhe anime aur chai pasand hai`)
- `/memory` — Saved notes dekhein
- `/forget [number]` — Kisi note ko delete karein
- `/clear` — Chat aur conversation history clear karein
